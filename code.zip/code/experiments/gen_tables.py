"""Generate LaTeX tables and number-macros from results/results.json.

Run after experiments/run_all.py.  Produces:
  paper/tab_main.tex     -- main comparison table body
  paper/tab_ablation.tex -- ablation table body
  paper/tab_sens.tex     -- sensitivity table body
  paper/numbers.tex      -- \\newcommand macros for inline numbers
Every number in the manuscript therefore traces back to the actual runs.
"""
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
R = json.load(open(ROOT / "results" / "results.json"))
OUT = ROOT / "paper"
OUT.mkdir(exist_ok=True)

M_ORDER = ["random", "pca", "grid_las", "han2016", "halo"]
M_NAME = {"random": "Random", "pca": "PCA projection",
          "grid_las": "Grid--LAS", "han2016": "Tree-based~\\cite{han2016tree}",
          "halo": "\\textbf{HALO (ours)}"}
COLS = [("trust", 1, True), ("cont", 1, True), ("knn_label", 1, True),
        ("dcorr", 1, True), ("overlap", 0, False), ("utilisation", 1, True),
        ("rank_prom", 1, True), ("runtime", 0, None)]


def fmt(mean, std, dec=3):
    return f"{mean:.{dec}f}\\,$\\pm$\\,{std:.{dec}f}"


def best_mask(block, key, hi):
    vals = {m: block[m][key][0] for m in M_ORDER}
    tgt = max(vals.values()) if hi else min(vals.values())
    return {m: abs(vals[m] - tgt) < 1e-9 for m in M_ORDER}


def main_table():
    files = {"digits-200": "tab_digits.tex", "colortex-300": "tab_ctx.tex"}
    for dset, fname in files.items():
        block = R[dset]
        lines = []
        for m in M_ORDER:
            row = [M_NAME[m]]
            for key, hi, is_hi in COLS:
                mean, std = block[m][key]
                dec = 2 if key == "runtime" else 3
                cell = fmt(mean, std, dec)
                if is_hi is not None and best_mask(block, key, is_hi)[m]:
                    cell = r"\textbf{" + cell + "}"
                row.append(cell)
            lines.append(" & ".join(row) + r"\\")
        out = "\n".join(lines)
        if out.endswith("\\\\"):
            out = out[:-2]
        open(OUT / fname, "w").write(out)


AB_ORDER = ["None", "no_hyp", "init_only", "no_stress", "no_micro"]
AB_NAME = {"None": "\\textbf{Full HALO}",
           "no_hyp": "w/o hyperbolic anchor",
           "init_only": "anchor only (no refinement)",
           "no_stress": "w/o stress term",
           "no_micro": "w/o micro-tuning"}


def ablation_table():
    lines = []
    for m in AB_ORDER:
        b = R["ablation"][m]
        cells = [AB_NAME[m],
                 fmt(*b["trust"]), fmt(*b["knn_label"]),
                 fmt(*b["overlap"]), fmt(*b["max_overlap"]),
                 fmt(*b["utilisation"]), fmt(*b["rank_prom"])]
        lines.append(" & ".join(cells) + r"\\")
    out = "\n".join(lines)
    if out.endswith("\\\\"):
        out = out[:-2]
    open(OUT / "tab_ablation.tex", "w").write(out)


def sens_table():
    lines = []
    for w in sorted(R["sensitivity"], key=float):
        b = R["sensitivity"][w]
        lines.append(f"{w} & {b['overlap']:.3f} & {b['utilisation']:.3f} & "
                     f"{b['trust']:.3f}" + r"\\")
    out = "\n".join(lines)
    if out.endswith("\\\\"):
        out = out[:-2]
    open(OUT / "tab_sens.tex", "w").write(out)


def macros():
    mac = []

    def add(name, val):
        mac.append(f"\\newcommand{{\\{name}}}{{{val}}}")

    sc = R["scaling"]
    for n, t in sc.items():
        add(f"tScale{'ABCD'[['100','200','300','400'].index(str(n))]}",
            f"{t:.1f}")
    h = R["colortex-300"]["halo"]
    add("haloUtilCtx", f"{h['utilisation'][0]:.3f}")
    add("haloOvCtx", f"{h['overlap'][0]:.3f}")
    add("haloTrustCtx", f"{h['trust'][0]:.3f}")
    add("haloPromCtx", f"{h['rank_prom'][0]:.3f}")
    add("haloTimeCtx", f"{h['runtime'][0]:.1f}")
    g = R["colortex-300"]["grid_las"]
    add("gridPromCtx", f"{g['rank_prom'][0]:.3f}")
    add("gridTrustCtx", f"{g['trust'][0]:.3f}")
    p = R["colortex-300"]["pca"]
    add("pcaOvCtx", f"{p['overlap'][0]:.2f}")
    add("pcaUtilCtx", f"{p['utilisation'][0]:.3f}")
    hd = R["digits-200"]["halo"]
    add("haloUtilDig", f"{hd['utilisation'][0]:.3f}")
    add("haloTrustDig", f"{hd['trust'][0]:.3f}")
    pd_ = R["digits-200"]["pca"]
    add("pcaTrustDig", f"{pd_['trust'][0]:.3f}")
    ab = R["ablation"]
    add("abNoHypTrust", f"{ab['no_hyp']['trust'][0]:.3f}")
    add("abInitOv", f"{ab['init_only']['overlap'][0]:.2f}")
    add("abInitUtil", f"{ab['init_only']['utilisation'][0]:.3f}")
    add("abInitTrust", f"{ab['init_only']['trust'][0]:.3f}")
    add("abNoMicroMax", f"{ab['no_micro']['max_overlap'][0]:.3f}")
    add("abNoStressTrust", f"{ab['no_stress']['trust'][0]:.3f}")
    add("fullMaxOv", f"{ab['None']['max_overlap'][0]:.3f}")
    open(OUT / "numbers.tex", "w").write("\n".join(mac) + "\n")


if __name__ == "__main__":
    main_table()
    ablation_table()
    sens_table()
    macros()
    print("tables + macros written")
