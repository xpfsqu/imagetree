"""Run the full experimental protocol and dump results + figures.

Everything reported in the manuscript is produced by this script.
"""
import json
import sys
import time
import pathlib

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from halo.data import make_digits, make_colortex           # noqa: E402
from halo.shapes import Shape                              # noqa: E402
from halo.methods import METHODS, run_halo                 # noqa: E402
from halo.metrics import evaluate                          # noqa: E402
from halo.render import render                             # noqa: E402
from halo.hyperbolic import poincare_embed, mobius_translate  # noqa: E402

RES = ROOT / "results"; RES.mkdir(exist_ok=True)
FIG = ROOT / "figures"; FIG.mkdir(exist_ok=True)
SEEDS = [0, 1, 2]

plt.rcParams.update({"font.size": 8, "pdf.fonttype": 42})


def agg(rows):
    keys = [k for k in rows[0] if k != "method"]
    return {k: (float(np.mean([r[k] for r in rows])),
                float(np.std([r[k] for r in rows]))) for k in keys}


def main():
    datasets = {
        "digits-200": (make_digits(200, seed=0), Shape("circle")),
        "colortex-300": (make_colortex(300, seed=1), Shape("heart")),
    }
    results = {}

    # ---------------------------------------------------- main comparison
    for dname, (data, shape) in datasets.items():
        results[dname] = {}
        for mname, fn in METHODS.items():
            rows = []
            for sd in SEEDS:
                P, s, dt = fn(data, shape, seed=sd)
                rows.append(evaluate(mname, data["X"], data["labels"], shape,
                                     P, s, data["aspects"],
                                     np.arange(len(s)), dt))
            results[dname][mname] = agg(rows)
            print(dname, mname, {k: round(v[0], 3)
                                 for k, v in results[dname][mname].items()})

    # -------------------------------------------------------------- ablation
    data, shape = datasets["colortex-300"]
    results["ablation"] = {}
    for ab in [None, "no_hyp", "init_only", "no_stress", "no_micro"]:
        rows = []
        for sd in SEEDS:
            P, s, dt = run_halo(data, shape, seed=sd, ablation=ab)
            rows.append(evaluate(str(ab), data["X"], data["labels"], shape,
                                 P, s, data["aspects"], np.arange(len(s)),
                                 dt))
        results["ablation"][str(ab)] = agg(rows)
        print("ablation", ab, {k: round(v[0], 3)
                               for k, v in results["ablation"][str(ab)].items()})

    # ------------------------------------------------ convergence + timing
    conv = {}
    for dname, (data, shape) in datasets.items():
        P, s, dt, extra = run_halo(data, shape, seed=0, return_extra=True)
        conv[dname] = dict(
            refine=[h["total"] for h in extra["hist"]],
            ov=[h["ov"] for h in extra["hist"]],
            sh=[h["sh"] for h in extra["hist"]],
            emb=list(map(float, extra["emb_hist"])))
    results["convergence_meta"] = {k: dict(iters=len(v["refine"]))
                                   for k, v in conv.items()}
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.3))
    for ax, (dname, c) in zip(axes, conv.items()):
        it = np.arange(1, len(c["refine"]) + 1)
        ax.plot(it, c["refine"], label="total $E$", lw=1.2)
        ax.plot(it, np.array(c["ov"]) * 140, label=r"$w_{ov}E_{ov}$", lw=1.0)
        ax.plot(it, np.array(c["sh"]) * 140, label=r"$w_{sh}E_{sh}$", lw=1.0)
        ax.set_yscale("log"); ax.set_xlabel("iteration")
        ax.set_title(dname); ax.grid(alpha=.3)
    axes[0].set_ylabel("energy")
    axes[1].legend(frameon=False, fontsize=7)
    fig.tight_layout(); fig.savefig(FIG / "convergence.pdf")
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(3.3, 2.2))
    for dname, c in conv.items():
        ax.plot(np.arange(1, len(c["emb"]) + 1), c["emb"], label=dname, lw=1.1)
    ax.set_yscale("log"); ax.set_xlabel("epoch")
    ax.set_ylabel("embedding loss"); ax.grid(alpha=.3)
    ax.legend(frameon=False, fontsize=7)
    fig.tight_layout(); fig.savefig(FIG / "embedding_convergence.pdf")
    plt.close(fig)

    # -------------------------------------------------- scaling with N
    results["scaling"] = {}
    for n in (100, 200, 300, 400):
        data_n = make_colortex(n, seed=1)
        t0 = time.time()
        run_halo(data_n, Shape("heart"), seed=0)
        results["scaling"][n] = float(time.time() - t0)
        print("scaling", n, results["scaling"][n])

    # -------------------------------------------------- sensitivity to tau/w
    results["sensitivity"] = {}
    data, shape = datasets["colortex-300"]
    for w_ov in (35, 70, 140, 280):
        from halo.hyperbolic import knn_graph, hyp_dist
        from halo.layout import Refiner, init_scales
        X = data["X"]; n = len(X)
        U, _ = poincare_embed(X, k=8, epochs=400, seed=0)
        P0 = shape.map_from_disk(U)
        pairs, _ = knn_graph(X, 8)
        dH = hyp_dist(U[pairs[:, 0]], U[pairs[:, 1]])
        d0 = np.linalg.norm(P0[pairs[:, 0]] - P0[pairs[:, 1]], axis=1)
        target = np.clip(np.median(d0) / np.median(dH) * dH,
                         .15 * np.sqrt(shape.area / n), 1.2)
        ref = Refiner(shape, data["aspects"], np.arange(n), pairs, target,
                      w_ov=w_ov, w_st=2.5, w_sz=3.5, w_an=0.2, seed=0)
        P, s, _ = ref.run(P0, init_scales(n, shape.area, data["aspects"]))
        P, s = ref.micro_tune(P, s, tau=0.12)
        m = evaluate(f"w{w_ov}", X, data["labels"], shape, P, s,
                     data["aspects"], np.arange(n), 0)
        results["sensitivity"][w_ov] = {k: m[k] for k in
                                        ("overlap", "utilisation", "trust")}
        print("sens", w_ov, results["sensitivity"][w_ov])

    # ------------------------------------------------------ qualitative fig
    for dname, (data, shape) in datasets.items():
        fig, axes = plt.subplots(1, 4, figsize=(7.0, 2.05))
        for ax, m in zip(axes, ["pca", "grid_las", "han2016", "halo"]):
            P, s, _ = METHODS[m](data, shape, seed=0)
            render(ax, shape, P, s, data["aspects"], data["thumbs"],
                   title={"pca": "PCA projection",
                          "grid_las": "Grid-LAS",
                          "han2016": "Tree-based (Han et al.)",
                          "halo": "HALO (ours)"}[m],
                   square=(m == "grid_las"))
        fig.tight_layout(pad=0.3)
        fig.savefig(FIG / f"qual_{dname}.pdf", dpi=220)
        fig.savefig(FIG / f"qual_{dname}.png", dpi=220)
        plt.close(fig)

    # stages figure: init -> refined -> micro-tuned (colortex, star shape)
    data = make_colortex(300, seed=1)
    shp = Shape("star")
    P, s, _, extra = run_halo(data, shp, seed=0, return_extra=True)
    Pi, si = extra["P0"], extra["s0"]
    Pr, sr, _ = run_halo(data, shp, seed=0, ablation="no_micro")
    fig, axes = plt.subplots(1, 3, figsize=(6.9, 2.35))
    render(axes[0], shp, Pi, si, data["aspects"], data["thumbs"],
           title="(a) hyperbolic anchor")
    render(axes[1], shp, Pr, sr, data["aspects"], data["thumbs"],
           title="(b) after refinement")
    render(axes[2], shp, P, s, data["aspects"], data["thumbs"],
           title="(c) after micro-tuning")
    fig.tight_layout(pad=0.3)
    fig.savefig(FIG / "stages.pdf", dpi=220); plt.close(fig)

    # ------------------------------------------------ Moebius re-anchoring
    data, shape = datasets["colortex-300"]
    X = data["X"]
    U, _ = poincare_embed(X, k=8, epochs=400, seed=0)
    focus = 137
    U2 = mobius_translate(U, U[focus])
    fig, axes = plt.subplots(1, 2, figsize=(4.9, 2.35))
    for ax, UU, tt in ((axes[0], U, "(a) initial anchor"),
                       (axes[1], U2, f"(b) re-anchored on image {focus}")):
        from halo.layout import Refiner, init_scales
        from halo.hyperbolic import knn_graph, hyp_dist
        P0 = shape.map_from_disk(UU)
        pairs, _ = knn_graph(X, 8)
        dH = hyp_dist(UU[pairs[:, 0]], UU[pairs[:, 1]])
        d0 = np.linalg.norm(P0[pairs[:, 0]] - P0[pairs[:, 1]], axis=1)
        target = np.clip(np.median(d0) / np.median(dH) * dH,
                         .15 * np.sqrt(shape.area / len(X)), 1.2)
        ranks = np.arange(len(X)) if UU is U else \
            np.argsort(np.argsort(hyp_dist(UU, UU[focus][None, :])))
        ref = Refiner(shape, data["aspects"], ranks, pairs, target, seed=0)
        s0 = init_scales(len(X), shape.area, data["aspects"])[
            np.argsort(np.argsort(ranks))] if UU is not U else \
            init_scales(len(X), shape.area, data["aspects"])
        P, s, _ = ref.run(P0, s0)
        P, s = ref.micro_tune(P, s)
        render(ax, shape, P, s, data["aspects"], data["thumbs"],
               ranks=ranks, title=tt)
        if UU is U2:
            i = focus
            ax.plot(P[i, 0], P[i, 1], marker="o", mfc="none", mec="red",
                    ms=14, mew=1.6, zorder=5)
    fig.tight_layout(pad=0.3)
    fig.savefig(FIG / "reanchor.pdf", dpi=220); plt.close(fig)

    with open(RES / "results.json", "w") as f:
        json.dump(results, f, indent=1)
    print("DONE")


if __name__ == "__main__":
    main()
