# HALO: Hyperbolic-Anchored Layout Optimization

Reference implementation and full experimental protocol for the paper

> HALO: Hyperbolic-anchored differentiable layout optimization for
> shape-constrained visualization of ordered image collections
> Yinjie Jia and Pengfei Xu, School of Information Engineering,
> Suqian University.

HALO lays out an ordered image collection (for example a ranked
retrieval result) inside an arbitrary star-shaped canvas so that five
competing goals are reconciled simultaneously:

- every image stays inside the shape (hard guarantee);
- the per-image overlap ratio is capped at a threshold `tau` (hard guarantee);
- the canvas is densely filled (contact-equilibrium size growth);
- on-screen proximity reflects feature similarity (hyperbolic stress);
- visual prominence decreases with rank (radial rank prior + size tiers).

This repository reproduces every number, table and figure in the
manuscript from a single command, using only NumPy / SciPy / scikit-learn /
Matplotlib on one CPU core.

---

## Description

HALO replaces the discrete tree backbone of earlier focus+context image
browsers with two coupled continuous optimizations:

1. Rank-aware hyperbolic anchoring (`halo/hyperbolic.py`) — the mutual
   k-nearest-neighbour similarity graph of the collection is embedded into
   the Poincaré disk by Riemannian gradient descent on a hyperbolic stress
   objective augmented with a radial rank prior, so that top-ranked
   images settle near the disk centre (the focus region) while similarity
   is encoded by geodesic proximity. A Möbius translation re-centres the
   embedding on any image of interest as an exact isometry (interest-driven
   re-anchoring).
2. Star-shaped transfer (`halo/shapes.py`) — polar-boundary domains
   (circle / cardioid heart / 5-point star), centroid re-parametrisation,
   and the radial signed-distance function with its closed-form gradient.
3. Unified differentiable refinement (`halo/layout.py`) — one smooth
   energy (softplus overlap surrogate + signed-distance containment +
   neighbourhood stress + rank-weighted anchoring + size-growth pressure)
   minimized with Adam using closed-form gradients, followed by a discrete
   micro-tuning pass that enforces containment exactly and caps the
   per-image overlap ratio at `tau`.

Four baselines are provided in `halo/methods.py`: `random`, `pca`,
`grid_las` (a linear-assignment grid in the spirit of Barthel et al., CGF
2023) and `han2016` (our reimplementation, in spirit, of the tree-based
two-step scheme of Han et al., IEEE TCYB 2016).

---

## Dataset information

No external dataset download is required; both collections are generated in
code (`halo/data.py`) and are deterministic given the seed.

| Collection       | N   | Thumbnail        | Features (`X`)                         | Domain | Source |
|------------------|-----|------------------|----------------------------------------|--------|--------|
| digits-200   | 200 | 8×8 grayscale    | standardized raw pixels, `d = 64`      | circle | real — `sklearn.datasets.load_digits` (UCI "Optical Recognition of Handwritten Digits") |
| colortex-300 | 300 | 32×32 RGB        | 4×4×4 = 64-bin colour histogram, L2-normalized | heart (cardioid) | synthetic — procedurally rendered, 12 latent clusters, mixed aspect ratios {3:4, 1:1, 4:3} |

In both cases the collection is ordered: images are sorted by ascending
feature distance to the first image (the query), emulating a retrieval
ranking. `labels` (digit class / latent cluster) are used only to compute
semantic metrics, never by the layout methods.

The real `digits` corpus ships with scikit-learn (BSD-licensed); the
synthetic `colortex` corpus has no external dependency and is fully
reproducible from `halo/data.py`.

---

## Code information

```
code/
├── halo/                     core package
│   ├── __init__.py
│   ├── data.py               dataset generation + rank ordering
│   ├── hyperbolic.py         Poincaré embedding, k-NN graph, Möbius translation
│   ├── shapes.py             star-shaped domains, signed distance + gradient, disk->domain map
│   ├── layout.py             differentiable energy + closed-form gradients, Adam, micro-tuning
│   ├── methods.py            HALO pipeline + 4 baselines (random/pca/grid_las/han2016)
│   ├── metrics.py            semantic, geometric and rank-prominence metrics
│   └── render.py             thumbnail rendering for the qualitative figures
├── experiments/
│   ├── run_all.py            runs the whole protocol -> results/results.json + figures/
│   └── gen_tables.py         converts results.json -> LaTeX table bodies + number macros
├── results/
│   └── results.json          generated metrics (main / ablation / scaling / sensitivity)
└── figures/                  generated figures (PDF + PNG)
```

Mapping from paper to code (for reviewers):

| Paper element                                        | Code |
|------------------------------------------------------|------|
| Eq. (1) Poincaré distance                            | `hyperbolic.hyp_dist` |
| Eq. (2) embedding loss (stress + radial rank prior)  | `hyperbolic.poincare_embed` |
| Eq. (3) star-shaped map Φ                            | `shapes.Shape.map_from_disk` |
| radial signed distance φ and ∇φ                      | `shapes.Shape.sdf`, `grad_sdf` |
| Eq. (4) unified energy E and all five terms          | `layout.Refiner.energy_and_grad` |
| Adam refinement                                      | `layout.Refiner.run` |
| micro-tuning (hard guarantees)                       | `layout.Refiner.micro_tune` |
| Möbius re-anchoring                                  | `hyperbolic.mobius_translate` |
| Table 1 / 2 / 3 metrics                              | `metrics.py` |

---

## Requirements

- Python ≥ 3.9
- `numpy` (≥ 1.20; ≥ 2.0 recommended — `shapes.py` uses `numpy.trapezoid`)
- `scipy`
- `scikit-learn`
- `matplotlib`
- a LaTeX distribution with `natbib` (TeX Live) — only if you want to
  recompile the manuscript PDF

Install:

```bash
pip install "numpy>=2.0" scipy scikit-learn matplotlib
```

> Note on NumPy version. `halo/shapes.py` calls `numpy.trapezoid`,
> which was renamed from `numpy.trapz` in NumPy 2.0. On NumPy < 2.0 either
> upgrade NumPy or replace `np.trapezoid` with `np.trapz`.

Tested configuration: single CPU core; pure CPU, no GPU required.

---

## Usage instructions

From the `code/` directory:

```bash
# 1. reproduce every metric and figure in the paper
python experiments/run_all.py        # writes results/results.json and figures/

# 2. convert the results into LaTeX tables + inline-number macros
python experiments/gen_tables.py     # writes paper/{numbers,tab_digits,tab_ctx,tab_ablation,tab_sens}.tex
```

`run_all.py` regenerates, in order: the main comparison (3 seeds × 2
collections), the ablation study, the convergence curves, the N-scaling
timings, the overlap-weight sensitivity sweep, the qualitative renders, the
pipeline-stages figure and the Möbius re-anchoring demonstration.
`gen_tables.py` turns `results/results.json` into the table bodies and the
`\newcommand` number macros that the manuscript `\input`s, so the paper can
never drift from the actual experimental output.

### Using HALO on your own collection

```python
import numpy as np
from halo.shapes import Shape
from halo.methods import run_halo

data = dict(
    X=my_features,              # (N, d) float array, rows ordered by rank
    aspects=my_aspect_ratios,   # (N,) width/height per image
    thumbs=my_thumbnails,       # list of HxWx3 arrays (only for rendering)
    labels=my_labels,           # (N,) ints (only for metrics; optional otherwise)
)
shape = Shape("heart")          # or "circle" / "star"
P, s, dt = run_halo(data, shape, seed=0)   # P: (N,2) centres, s: (N,) scales
```

Deep features plug in unchanged: provide them as the `X` matrix.

### Recompiling the manuscript (optional)

The LaTeX sources (`manuscript.tex`, `refs.bib`) are distributed with the
paper submission rather than inside this code archive. To rebuild the PDF,
place them next to the generated `paper/.tex` files, with the generated
`figures/` one level up, then:

```bash
cd paper && latexmk -pdf manuscript.tex
```

---

## Methodology (data processing)

- digits-200. 200 images are drawn (seeded permutation) from the 1797-image
  scikit-learn digits corpus. Each 8×8 image in [0, 16] is flattened to a
  64-D vector and z-score standardized per pixel (mean 0, unit std;
  `+1e-9` guard). Thumbnails are the images inverted to dark-on-white RGB.
- colortex-300. 300 thumbnails are rendered procedurally in 12 latent
  clusters (cluster `c = i mod 12`); each gets a cluster hue perturbed by
  small Gaussian noise and one of four texture kinds, plus mild additive
  noise. The feature vector is a 4×4×4 = 64-bin RGB colour histogram,
  L1-normalized then L2-normalized. Aspect ratios are sampled from
  {3:4, 1:1, 4:3}.
- Rank ordering (both collections). Features are reordered by ascending
  Euclidean distance to the first sample, so row `i` has rank `i` — an
  emulated retrieval ranking consumed by the radial rank prior.
- k-NN similarity graph. A mutual k-NN graph (`k = 8`) is built on `X`;
  edge feature distances are mapped to target geodesic lengths by an affine
  normalization of their [5, 95] percentile range into [0.15, 1.4].

No other preprocessing (no PCA/whitening of inputs, no cropping) is applied;
PCA is used only inside the `pca`/`grid_las` baselines and to initialise
embedding angles.

---

## Reproducibility notes

- All randomness is seeded; the paper reports mean ± std over seeds
  `{0, 1, 2}`.
- Metrics are computed by the same code (`metrics.py`) for every method,
  including the baselines, for a like-for-like comparison.
- `results/results.json` in this archive is the exact output used to
  typeset the submitted tables; rerunning `run_all.py` overwrites it with a
  bit-for-bit equivalent result on the same platform.

---

## Citation

If you use this code, please cite:

```bibtex
@article{jia2026halo,
  author  = {Jia, Yinjie and Xu, Pengfei},
  title   = {HALO: Hyperbolic-anchored differentiable layout optimization
             for shape-constrained visualization of ordered image collections},
  year    = {2026}
}
```

(Update with the final venue, volume and DOI once available.)

The real image corpus is the scikit-learn / UCI handwritten digits dataset.

---

## License & contribution

Released under the MIT License (see `LICENSE`).

Contributions are welcome via pull request. Please keep the pure
NumPy/SciPy, single-file-per-concern structure, and ensure
`python experiments/run_all.py` still reproduces `results/results.json`
before submitting.
