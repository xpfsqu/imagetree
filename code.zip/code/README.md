# HALO: Hyperbolic-Anchored Layout Optimization

Reference implementation and full experimental protocol for the paper

HALO lays out an **ordered image collection** (e.g. a ranked retrieval
result) inside an **arbitrary star-shaped canvas** so that

* every image stays inside the shape (hard guarantee),
* the per-image overlap ratio is capped at a threshold tau (hard guarantee),
* the canvas is densely filled (contact-equilibrium size growth),
* on-screen proximity reflects feature similarity (hyperbolic stress),
* visual prominence decreases with rank (radial rank prior + size tiers).

## Layout pipeline

1. **Rank-aware Poincare embedding** (`halo/hyperbolic.py`) — Riemannian
   gradient descent on hyperbolic stress with a radial rank prior;
   Moebius translation for exact isometric re-anchoring.
2. **Star-shaped transfer** (`halo/shapes.py`) — polar-boundary domains
   (circle / heart / star), centroid re-parametrisation, radial signed
   distance and its gradient.
3. **Differentiable refinement** (`halo/layout.py`) — one smooth energy
   (softplus overlap + SDF containment + stress + anchor + size growth),
   closed-form gradients, Adam; then discrete micro-tuning that enforces
   the hard constraints.

Baselines (`halo/methods.py`): random, PCA projection, linear-assignment
grid (in the spirit of Barthel et al., CGF 2023), and a reimplementation
in spirit of the tree-based two-step scheme of Han et al. (IEEE TCYB
2016).

## Reproducing the paper

```bash
pip install numpy scipy scikit-learn matplotlib
python experiments/run_all.py      # ~10 min on one CPU core
python experiments/gen_tables.py   # LaTeX tables + number macros
cd paper && latexmk -pdf manuscript.tex
```

`run_all.py` regenerates every number and figure of the paper:
main comparison (3 seeds), ablations, convergence curves, N-scaling,
overlap-weight sensitivity, qualitative renders and the re-anchoring
demonstration. `gen_tables.py` converts `results/results.json` into the
table bodies and inline-number macros included by the manuscript, so the
paper cannot drift from the actual experimental output.

## Repository layout

```
halo/            core package (embedding, shapes, layout, metrics, render)
experiments/     run_all.py (protocol), gen_tables.py (LaTeX generation)
results/         results.json + run log (generated)
figures/         all figures (generated)
```

## Notes on scope

Experiments use small-to-medium collections (N <= 400) with classical
features (raw pixels, colour histograms) on one real image corpus
(scikit-learn digits) and one controlled synthetic corpus; deep features
plug in unchanged via the `X` matrix. See Section "Limitations" of the
paper for an explicit statement of what has and has not been validated.

## License

MIT.
