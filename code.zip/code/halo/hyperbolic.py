"""Rank-aware Poincare-disk embedding (the 'hyperbolic anchor' of HALO).

Given features X (already ordered by collection rank, rank i = row i) we embed
the k-NN similarity graph into the Poincare disk by Riemannian gradient
descent on a hyperbolic stress objective, augmented with a *radial rank
prior*: the hyperbolic distance of point i to the origin is attracted towards
a monotone function of its rank.  High-rank (top of the ordered collection)
images therefore settle near the disk centre -- the natural focus region of a
focus+context display -- while similarity is encoded in geodesic proximity.

A Moebius translation is provided for interest-driven re-anchoring: it is an
isometry of the disk that moves any chosen image to the centre while exactly
preserving all pairwise hyperbolic distances.
"""
import numpy as np
from sklearn.neighbors import NearestNeighbors

EPS = 1e-7
MAX_NORM = 1.0 - 1e-4


def hyp_dist(u, v):
    """Poincare distance between rows of u and rows of v (broadcastable)."""
    du = np.sum((u - v) ** 2, axis=-1)
    bu = 1.0 - np.sum(u ** 2, axis=-1)
    bv = 1.0 - np.sum(v ** 2, axis=-1)
    z = 1.0 + 2.0 * du / (bu * bv + EPS)
    return np.arccosh(np.maximum(z, 1.0 + EPS))


def _project(u):
    n = np.linalg.norm(u, axis=-1, keepdims=True)
    f = np.where(n >= MAX_NORM, MAX_NORM / (n + EPS), 1.0)
    return u * f


def knn_graph(X, k=8):
    nn = NearestNeighbors(n_neighbors=k + 1).fit(X)
    d, idx = nn.kneighbors(X)
    pairs, dist = [], []
    for i in range(X.shape[0]):
        for j, dd in zip(idx[i, 1:], d[i, 1:]):
            a, b = (i, j) if i < j else (j, i)
            pairs.append((a, b)); dist.append(dd)
    pairs, dist = np.array(pairs), np.array(dist)
    _, uniq = np.unique(pairs, axis=0, return_index=True)
    return pairs[uniq], dist[uniq]


def poincare_embed(X, k=8, epochs=400, lr=0.05, radial_w=0.6,
                   rho_max=2.4, seed=0, callback=None):
    """Returns (U, history): positions in the open unit disk + loss history."""
    rng = np.random.default_rng(seed)
    n = X.shape[0]
    pairs, fdist = knn_graph(X, k)
    # target geodesic lengths: normalise feature distances to [0.15, 1.4]
    lo, hi = np.percentile(fdist, 5), np.percentile(fdist, 95)
    tgt = 0.15 + 1.25 * np.clip((fdist - lo) / (hi - lo + EPS), 0, 1)
    # radial prior: hyperbolic radius grows with rank percentile
    q = (np.arange(n) / max(n - 1, 1)) ** 0.7
    rho_tgt = 0.25 + (rho_max - 0.25) * q
    # init: angles spread by feature PCA order, radii from prior
    from sklearn.decomposition import PCA
    a = PCA(1).fit_transform(X).ravel()
    theta = 2 * np.pi * np.argsort(np.argsort(a)) / n + rng.normal(0, .15, n)
    r_eu = np.tanh(rho_tgt / 2.0) * 0.9
    U = np.stack([r_eu * np.cos(theta), r_eu * np.sin(theta)], 1)
    i0, i1 = pairs[:, 0], pairs[:, 1]
    hist = []
    for ep in range(epochs):
        G = np.zeros_like(U)
        # ---- stress term on kNN graph ----
        u, v = U[i0], U[i1]
        diff = u - v
        A = np.sum(diff ** 2, 1)
        B = 1 - np.sum(u ** 2, 1)
        C = 1 - np.sum(v ** 2, 1)
        z = 1 + 2 * A / (B * C + EPS)
        d = np.arccosh(np.maximum(z, 1 + EPS))
        res = d - tgt
        common = 2 * res / np.sqrt(np.maximum(z ** 2 - 1, EPS))
        dz_du = (4 * diff) / (B * C + EPS)[:, None] \
            + (4 * A / (B ** 2 * C + EPS))[:, None] * u
        dz_dv = (-4 * diff) / (B * C + EPS)[:, None] \
            + (4 * A / (B * C ** 2 + EPS))[:, None] * v
        np.add.at(G, i0, common[:, None] * dz_du)
        np.add.at(G, i1, common[:, None] * dz_dv)
        loss = float(np.mean(res ** 2))
        # ---- radial rank prior ----
        nrm = np.linalg.norm(U, axis=1)
        rho = 2 * np.arctanh(np.minimum(nrm, MAX_NORM))
        rres = rho - rho_tgt
        gr = (2 * radial_w * rres / (1 - np.minimum(nrm, MAX_NORM) ** 2 + EPS)
              / (nrm + EPS))[:, None] * U * 2
        G += gr
        loss += radial_w * float(np.mean(rres ** 2))
        # ---- Riemannian step: rescale by inverse metric ((1-|u|^2)^2 / 4) ---
        scale = ((1 - np.sum(U ** 2, 1)) ** 2 / 4.0)[:, None]
        step = lr * (1.0 if ep < epochs * 0.7 else 0.3)
        U = _project(U - step * scale * G / max(len(pairs) / n, 1))
        hist.append(loss)
        if callback:
            callback(ep, loss, U)
    return U, np.array(hist)


def mobius_translate(U, a):
    """Isometry of the Poincare disk moving point ``a`` to the origin.

    Complex form:  T_a(z) = (z - a) / (1 - conj(a) z).
    """
    z = U[:, 0] + 1j * U[:, 1]
    a = complex(a[0], a[1])
    w = (z - a) / (1 - np.conj(a) * z)
    return _project(np.stack([w.real, w.imag], 1))
