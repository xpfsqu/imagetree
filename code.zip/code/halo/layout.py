"""Unified differentiable layout refinement (stage 2 of HALO).

All images are axis-aligned rectangles with centre p_i and scale s_i (aspect
ratio fixed).  A single smooth objective couples

  E = w_ov*E_overlap + w_sh*E_shape + w_st*E_stress + w_an*E_anchor + w_sz*E_size

and is minimised with Adam using closed-form gradients.  Overlap uses a
softplus surrogate of the rectangle-intersection area; the shape term
penalises the radial signed distance of the four rectangle corners; the
stress term ties on-screen distances of feature-space neighbours to their
hyperbolic anchor distances; the anchor term keeps images near their
hyperbolic initialisation (rank-weighted); the size term rewards growth.
A short discrete micro-tuning pass then enforces the hard overlap /
containment constraints exactly.
"""
import numpy as np


def softplus(x, beta):
    return np.logaddexp(0.0, beta * x) / beta


def sigmoid(x):
    return 0.5 * (1.0 + np.tanh(0.5 * x))


def base_halves(aspects):
    W = np.sqrt(aspects)          # width  factor (area of unit box == 1)
    H = 1.0 / np.sqrt(aspects)
    return W / 2.0, H / 2.0


def init_scales(n, shape_area, aspects, fill=0.55, tiers=(0.10, 0.30)):
    """Per-image initial scale with a rank-tier prominence prior."""
    mult = np.ones(n)
    mult[: int(tiers[0] * n)] = 1.7
    mult[int(tiers[0] * n): int(tiers[1] * n)] = 1.3
    unit = np.sqrt(fill * shape_area / (mult ** 2).sum())
    return unit * mult


def exact_overlap_matrix(P, s, aspects):
    Wh, Hh = base_halves(aspects)
    a, b = s * Wh, s * Hh
    dx = np.abs(P[:, 0][:, None] - P[:, 0][None, :])
    dy = np.abs(P[:, 1][:, None] - P[:, 1][None, :])
    ox = np.maximum(a[:, None] + a[None, :] - dx, 0.0)
    oy = np.maximum(b[:, None] + b[None, :] - dy, 0.0)
    O = ox * oy
    np.fill_diagonal(O, 0.0)
    return O


class Refiner:
    def __init__(self, shape, aspects, ranks, pairs, target_d,
                 w_ov=140.0, w_sh=140.0, w_st=1.2, w_an=0.35, w_sz=3.0,
                 beta_ov=None, beta_sh=None, lr=0.012, iters=500, seed=0):
        self.shape, self.aspects = shape, np.asarray(aspects, float)
        self.n = len(aspects)
        self.ranks = ranks
        self.pairs, self.target_d = pairs, target_d
        self.w = dict(ov=w_ov, sh=w_sh, st=w_st, an=w_an, sz=w_sz)
        self.lr, self.iters = lr, iters
        # softplus sharpness relative to typical thumbnail size
        self.unit = np.sqrt(shape.area / self.n)
        self.beta_ov = beta_ov or 14.0 / self.unit
        self.beta_sh = beta_sh or 20.0 / self.unit
        self.rng = np.random.default_rng(seed)

    # ---------------------------------------------------------------- energy
    def energy_and_grad(self, P, s, P0, s_hi):
        n = self.n
        Wh, Hh = base_halves(self.aspects)
        a, b = s * Wh, s * Hh
        gP = np.zeros_like(P)
        gs = np.zeros_like(s)
        E = {}

        # overlap ------------------------------------------------------------
        dx = P[:, 0][:, None] - P[:, 0][None, :]
        dy = P[:, 1][:, None] - P[:, 1][None, :]
        mx = a[:, None] + a[None, :] - np.abs(dx)
        my = b[:, None] + b[None, :] - np.abs(dy)
        spx, spy = softplus(mx, self.beta_ov), softplus(my, self.beta_ov)
        sgx, sgy = sigmoid(self.beta_ov * mx), sigmoid(self.beta_ov * my)
        np.fill_diagonal(spx, 0); np.fill_diagonal(spy, 0)
        O = spx * spy
        norm = 1.0 / (n * self.unit ** 2)
        E['ov'] = O.sum() * 0.5 * norm
        dO_dxi = sgx * (-np.sign(dx)) * spy
        dO_dyi = spx * sgy * (-np.sign(dy))
        gP[:, 0] += self.w['ov'] * norm * dO_dxi.sum(1)
        gP[:, 1] += self.w['ov'] * norm * dO_dyi.sum(1)
        ds = (sgx * spy) * Wh[:, None] + (spx * sgy) * Hh[:, None]
        gs += self.w['ov'] * norm * ds.sum(1)

        # shape containment ----------------------------------------------------
        e_sh = 0.0
        for sx in (-1, 1):
            for sy in (-1, 1):
                corner = P + np.stack([sx * a, sy * b], 1)
                sd = self.shape.sdf(corner)
                sp = softplus(sd, self.beta_sh)
                sg = sigmoid(self.beta_sh * sd)
                e_sh += (sp ** 2).sum()
                gsd = self.shape.grad_sdf(corner)
                coef = (2 * sp * sg)[:, None] * gsd
                gP += self.w['sh'] / self.unit * coef
                gs += self.w['sh'] / self.unit * (
                    coef[:, 0] * sx * Wh + coef[:, 1] * sy * Hh)
        E['sh'] = e_sh / self.unit

        # neighbourhood stress -------------------------------------------------
        i0, i1 = self.pairs[:, 0], self.pairs[:, 1]
        d2 = P[i0] - P[i1]
        dist = np.linalg.norm(d2, axis=1) + 1e-9
        res = dist - self.target_d
        E['st'] = float(np.mean(res ** 2)) / self.unit ** 2
        coef = (2 * res / dist / len(res))[:, None] * d2 / self.unit ** 2
        np.add.at(gP, i0, self.w['st'] * coef)
        np.add.at(gP, i1, -self.w['st'] * coef)

        # anchor ---------------------------------------------------------------
        omg = 1.0 + 2.0 * np.exp(-self.ranks / (0.10 * n))
        diff0 = P - P0
        E['an'] = float((omg * (diff0 ** 2).sum(1)).mean()) / self.unit ** 2
        gP += self.w['an'] * 2 * omg[:, None] * diff0 / (n * self.unit ** 2)

        # size growth ----------------------------------------------------------
        # constant per-image growth pressure: each image expands until the
        # marginal overlap/shape gradient balances w_sz (contact equilibrium)
        E['sz'] = float(np.mean((s_hi - s) / s_hi))
        grow = 1.0 + 2.0 * np.exp(-self.ranks / (0.10 * n))
        gs += -self.w['sz'] * grow

        E['total'] = sum(self.w[k] * E[k] for k in ('ov', 'sh', 'st', 'an')) \
            + self.w['sz'] * E['sz']
        return E, gP, gs

    # ------------------------------------------------------------------ run
    def run(self, P_init, s_init):
        P = P_init.copy()
        s = s_init.copy()
        P0 = P_init.copy()
        s_lo, s_hi = 0.78 * s_init, 1.45 * s_init
        mP = np.zeros_like(P); vP = np.zeros_like(P)
        ms = np.zeros_like(s); vs = np.zeros_like(s)
        b1, b2, eps = 0.9, 0.999, 1e-8
        hist = []
        for t in range(1, self.iters + 1):
            E, gP, gs = self.energy_and_grad(P, s, P0, s_hi)
            hist.append(E)
            mP = b1 * mP + (1 - b1) * gP; vP = b2 * vP + (1 - b2) * gP ** 2
            ms = b1 * ms + (1 - b1) * gs; vs = b2 * vs + (1 - b2) * gs ** 2
            c1, c2 = 1 - b1 ** t, 1 - b2 ** t
            lr = self.lr * self.unit * (1.0 if t < 0.75 * self.iters else 0.35)
            P -= lr * (mP / c1) / (np.sqrt(vP / c2) + eps)
            s -= 0.6 * lr * (ms / c1) / (np.sqrt(vs / c2) + eps)
            s = np.clip(s, s_lo, s_hi)
        return P, s, hist

    # -------------------------------------------------------- micro-tuning
    def micro_tune(self, P, s, tau=0.05, rounds=40):
        Wh, Hh = base_halves(self.aspects)
        for _ in range(rounds):
            O = exact_overlap_matrix(P, s, self.aspects)
            area = (2 * s * Wh) * (2 * s * Hh)
            ratio = O.sum(1) / area
            viol = ratio > tau
            # containment
            moved = False
            for sx in (-1, 1):
                for sy in (-1, 1):
                    corner = P + np.stack([sx * s * Wh, sy * s * Hh], 1)
                    sd = self.shape.sdf(corner)
                    out = sd > 0
                    if out.any():
                        g = self.shape.grad_sdf(corner[out])
                        g /= np.linalg.norm(g, axis=1, keepdims=True) + 1e-9
                        P[out] -= (sd[out] * 1.02)[:, None] * g
                        moved = True
            if viol.any():
                s[viol] *= 0.97
                moved = True
            if not moved:
                break
        return P, s
