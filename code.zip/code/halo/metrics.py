"""Objective quality metrics for image-collection layouts."""
import numpy as np
from scipy.stats import spearmanr
from sklearn.manifold import trustworthiness
from sklearn.neighbors import NearestNeighbors

from .layout import exact_overlap_matrix, base_halves


def semantic_metrics(X, P, labels, k=10, n_pairs=20000, seed=0):
    rng = np.random.default_rng(seed)
    n = len(X)
    tw = trustworthiness(X, P, n_neighbors=k)
    co = trustworthiness(P, X, n_neighbors=k)           # continuity
    nn = NearestNeighbors(n_neighbors=k + 1).fit(P)
    _, idx = nn.kneighbors(P)
    knnc = float(np.mean(labels[idx[:, 1:]] == labels[:, None]))
    i = rng.integers(0, n, n_pairs)
    j = rng.integers(0, n, n_pairs)
    m = i != j
    dh = np.linalg.norm(X[i[m]] - X[j[m]], axis=1)
    d2 = np.linalg.norm(P[i[m]] - P[j[m]], axis=1)
    rho = float(spearmanr(dh, d2).statistic)
    return dict(trust=float(tw), cont=float(co), knn_label=knnc, dcorr=rho)


def geometric_metrics(shape, P, s, aspects, raster=640):
    n = len(s)
    Wh, Hh = base_halves(aspects)
    a, b = s * Wh, s * Hh
    area = (2 * a) * (2 * b)
    O = exact_overlap_matrix(P, s, aspects)
    overlap_ratio = float(O.sum() * 0.5 / area.sum())
    max_overlap = float((O.sum(1) / area).max())
    # rasterise union of rectangles and the domain
    lim = shape.R * 1.35
    xs = np.linspace(shape.c[0] - lim, shape.c[0] + lim, raster)
    ys = np.linspace(shape.c[1] - lim, shape.c[1] + lim, raster)
    XX, YY = np.meshgrid(xs, ys)
    pix = (2 * lim / raster) ** 2
    Ppix = np.stack([XX.ravel(), YY.ravel()], 1)
    inside_dom = (shape.sdf(Ppix) < 0).reshape(raster, raster)
    cover = np.zeros((raster, raster), bool)
    outside_mass = 0.0
    for i in range(n):
        mx = (XX >= P[i, 0] - a[i]) & (XX <= P[i, 0] + a[i]) \
            & (YY >= P[i, 1] - b[i]) & (YY <= P[i, 1] + b[i])
        cover |= mx
        outside_mass += float((mx & ~inside_dom).sum()) * pix
    utilisation = float((cover & inside_dom).sum() * pix / shape.area)
    outside_frac = float(outside_mass / area.sum())
    return dict(overlap=overlap_ratio, max_overlap=max_overlap,
                utilisation=utilisation, outside=outside_frac)


def rank_prominence(shape, P, s, ranks):
    """Spearman correlation between inverse rank and visual prominence
    (prominence = image area x centrality)."""
    d = np.linalg.norm(P - shape.c[None, :], axis=1)
    cen = 1.0 - d / (d.max() + 1e-9)
    prom = (s ** 2) * (0.25 + 0.75 * cen)
    rho = spearmanr(-ranks, prom).statistic
    return dict(rank_prom=float(rho))


def evaluate(name, X, labels, shape, P, s, aspects, ranks, runtime):
    m = dict(method=name, runtime=float(runtime))
    m.update(semantic_metrics(X, P, labels))
    m.update(geometric_metrics(shape, P, s, aspects))
    m.update(rank_prominence(shape, P, s, ranks))
    return m
