"""Star-shaped layout domains defined by a polar boundary function r(theta).

Circle, cardioid heart and 5-point star are all star-shaped with respect to
their centroid, so a point can be tested / penalised with the *radial signed
distance*  sdf(p) = |p - c| - r(theta(p)),  which is negative inside.  The
Poincare disk is mapped into the domain by scaling the (compressed) Euclidean
radius of each embedded point with the boundary radius along its angle.
"""
import numpy as np

_TH = np.linspace(-np.pi, np.pi, 2048, endpoint=False)


class Shape:
    def __init__(self, kind="circle", radius=1.0, center=(0.0, 0.0)):
        self.kind, self.R = kind, radius
        self.c = np.asarray(center, float)
        r_raw = self._r_of_theta(_TH)
        # boundary polyline in the raw frame, then re-parametrise the polar
        # table about the region centroid so that the disk origin maps to the
        # visual centre of the domain (matters for non-symmetric shapes)
        bx = r_raw * np.cos(_TH)
        by = r_raw * np.sin(_TH)
        A = 0.5 * np.sum(bx * np.roll(by, -1) - np.roll(bx, -1) * by)
        cx = np.sum((bx + np.roll(bx, -1)) *
                    (bx * np.roll(by, -1) - np.roll(bx, -1) * by)) / (6 * A)
        cy = np.sum((by + np.roll(by, -1)) *
                    (bx * np.roll(by, -1) - np.roll(bx, -1) * by)) / (6 * A)
        qx, qy = bx - cx, by - cy
        th_new = np.arctan2(qy, qx)
        rr_new = np.hypot(qx, qy)
        order = np.argsort(th_new)
        self._rt = np.interp(_TH, th_new[order], rr_new[order],
                             period=2 * np.pi)
        self._drt = np.gradient(self._rt, _TH)
        self.area = 0.5 * np.trapezoid(self._rt ** 2, _TH) \
            + 0.5 * self._rt[0] ** 2 * (_TH[1] - _TH[0])

    def _r_of_theta(self, th):
        if self.kind == "circle":
            return np.full_like(th, self.R)
        if self.kind == "heart":     # cardioid, apex down
            return self.R * 0.62 * (1.0 - np.sin(th)) + 0.22 * self.R
        if self.kind == "star":      # smooth 5-point star
            return self.R * (0.66 + 0.34 * np.cos(5 * th))
        raise ValueError(self.kind)

    def r_theta(self, th):
        return np.interp(th, _TH, self._rt, period=2 * np.pi)

    def dr_theta(self, th):
        return np.interp(th, _TH, self._drt, period=2 * np.pi)

    def sdf(self, P):
        q = P - self.c
        rr = np.linalg.norm(q, axis=-1)
        th = np.arctan2(q[..., 1], q[..., 0])
        return rr - self.r_theta(th)

    def grad_sdf(self, P):
        q = P - self.c
        rr = np.linalg.norm(q, axis=-1) + 1e-9
        th = np.arctan2(q[..., 1], q[..., 0])
        g_r = q / rr[..., None]
        dth = np.stack([-q[..., 1], q[..., 0]], -1) / (rr ** 2)[..., None]
        return g_r - self.dr_theta(th)[..., None] * dth

    def map_from_disk(self, U, gamma=0.85, margin=0.90):
        """Map Poincare-disk coordinates into the domain (star-shaped map)."""
        rr = np.linalg.norm(U, axis=1)
        th = np.arctan2(U[:, 1], U[:, 0])
        r_new = margin * self.r_theta(th) * np.clip(rr, 0, 1) ** gamma
        return self.c + np.stack([r_new * np.cos(th), r_new * np.sin(th)], 1)

    def sample_inside(self, n, rng, margin=0.92):
        out = []
        while len(out) < n:
            p = (rng.random((4 * n, 2)) * 2 - 1) * self.R * 1.4 + self.c
            ok = self.sdf(p) < -(1 - margin) * self.R
            out.extend(p[ok].tolist())
        return np.array(out[:n])

    def boundary(self, m=720):
        th = np.linspace(-np.pi, np.pi, m)
        r = self.r_theta(th)
        return self.c + np.stack([r * np.cos(th), r * np.sin(th)], 1)
