"""Datasets and features for HALO experiments.

Two collections are used:
  * digits-N   : real handwritten digit images (sklearn load_digits, 8x8 gray).
  * colortex-N : procedurally generated colour/texture thumbnails organised in
                 K latent clusters (32x32 RGB).

Each collection is "ordered": images are ranked by ascending feature distance
to a query image (the first image), emulating a retrieval result list.
"""
import numpy as np
from sklearn.datasets import load_digits


def _order_by_query(X, thumbs, labels, aspects):
    q = X[0]
    d = np.linalg.norm(X - q[None, :], axis=1)
    idx = np.argsort(d, kind="stable")
    return (X[idx], [thumbs[i] for i in idx], labels[idx],
            np.asarray(aspects, dtype=float)[idx])


def make_digits(n=200, seed=0):
    rng = np.random.default_rng(seed)
    ds = load_digits()
    sel = rng.permutation(len(ds.images))[:n]
    imgs = ds.images[sel]                      # (n, 8, 8) in [0,16]
    labels = ds.target[sel]
    X = imgs.reshape(n, -1).astype(float)
    X = (X - X.mean(0)) / (X.std(0) + 1e-9)
    thumbs, aspects = [], []
    for im in imgs:
        g = (im / 16.0)
        rgb = np.stack([1 - g, 1 - g, 1 - g], axis=-1)   # dark digits on white
        thumbs.append(rgb)
        aspects.append(1.0)
    X, thumbs, labels, aspects = _order_by_query(X, thumbs, labels, aspects)
    return dict(name=f"digits-{n}", X=X, thumbs=thumbs, labels=labels,
                aspects=aspects)


def _tex_thumb(hue_rgb, kind, rng, size=32):
    """Render one synthetic thumbnail: base colour + one of 4 texture kinds."""
    yy, xx = np.mgrid[0:size, 0:size] / (size - 1)
    if kind == 0:      # horizontal gradient
        t = xx
    elif kind == 1:    # vertical stripes
        t = 0.5 + 0.5 * np.sin(2 * np.pi * xx * rng.integers(3, 6))
    elif kind == 2:    # radial blob
        t = 1 - np.hypot(xx - 0.5, yy - 0.5) * 1.6
    else:              # checker
        f = rng.integers(3, 5)
        t = ((np.floor(xx * f) + np.floor(yy * f)) % 2)
    t = np.clip(t, 0, 1)[..., None]
    base = np.array(hue_rgb)[None, None, :]
    noise = rng.normal(0, 0.04, (size, size, 1))
    img = np.clip(0.25 + 0.75 * base * (0.35 + 0.65 * t) + noise, 0, 1)
    return img


def _color_hist(img, bins=4):
    h, _ = np.histogramdd(img.reshape(-1, 3), bins=(bins,) * 3,
                          range=((0, 1),) * 3)
    h = h.ravel().astype(float)
    return h / (h.sum() + 1e-9)


def make_colortex(n=300, k=12, seed=1):
    rng = np.random.default_rng(seed)
    hues = [(np.cos(2 * np.pi * c / k) * .5 + .5,
             np.cos(2 * np.pi * c / k + 2.1) * .5 + .5,
             np.cos(2 * np.pi * c / k + 4.2) * .5 + .5) for c in range(k)]
    thumbs, labels, aspects = [], [], []
    for i in range(n):
        c = i % k
        hue = np.clip(np.array(hues[c]) + rng.normal(0, 0.05, 3), 0, 1)
        thumbs.append(_tex_thumb(hue, c % 4, rng))
        labels.append(c)
        aspects.append(float(rng.choice([0.75, 1.0, 1.0, 1.333])))
    X = np.stack([_color_hist(t) for t in thumbs])
    X = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-9)
    labels = np.array(labels)
    X, thumbs, labels, aspects = _order_by_query(X, thumbs, np.array(labels),
                                                  aspects)
    return dict(name=f"colortex-{n}", X=X, thumbs=thumbs, labels=labels,
                aspects=aspects)
