"""HALO pipeline and the comparison baselines.

Baselines:
  random    -- uniform placement inside the domain, uniform size.
  pca       -- 2-D PCA projection scaled into the domain (mapping-based
               visualisation in the spirit of classical projection browsers).
  grid-las  -- similarity-preserving grid arrangement obtained by solving a
               linear assignment between projected positions and the grid
               cells contained in the domain (our reimplementation in the
               spirit of linear-assignment grid sorting, cf. Barthel et al.).
  han2016   -- our reimplementation, in spirit, of the tree-based two-step
               scheme of Han et al. (TCYB 2016): correlation-threshold tree
               levels, recursive hyperbolic wedge initialisation, and a
               penalty-based continuous optimisation without the stress term.
"""
import time
import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.decomposition import PCA

from .hyperbolic import poincare_embed, knn_graph, hyp_dist
from .layout import Refiner, init_scales
from .shapes import Shape


# --------------------------------------------------------------------- HALO
def run_halo(data, shape, iters=500, epochs=400, seed=0, ablation=None,
             return_extra=False):
    """ablation in {None,'no_hyp','init_only','no_stress','no_micro'}"""
    t0 = time.time()
    X, aspects = data['X'], data['aspects']
    n = len(X)
    ranks = np.arange(n)
    pairs, fdist = knn_graph(X, k=8)

    if ablation == 'no_hyp':
        rng = np.random.default_rng(seed)
        P0 = shape.sample_inside(n, rng)
        lo, hi = np.percentile(fdist, 5), np.percentile(fdist, 95)
        tgt = np.clip((fdist - lo) / (hi - lo + 1e-9), 0, 1)
        target_d = (0.2 + 1.1 * tgt) * np.sqrt(shape.area / n)
        emb_hist = np.array([])
    else:
        U, emb_hist = poincare_embed(X, k=8, epochs=epochs, seed=seed,
                                     radial_w=0.8)
        P0 = shape.map_from_disk(U, gamma=0.8)
        dH = hyp_dist(U[pairs[:, 0]], U[pairs[:, 1]])
        d0 = np.linalg.norm(P0[pairs[:, 0]] - P0[pairs[:, 1]], axis=1)
        kappa = np.median(d0) / (np.median(dH) + 1e-9)
        target_d = np.clip(kappa * dH, 0.15 * np.sqrt(shape.area / n),
                           1.2 * shape.R)

    s0 = init_scales(n, shape.area, aspects, fill=0.62)
    ref = Refiner(shape, aspects, ranks, pairs, target_d, seed=seed,
                  iters=iters, w_st=0.0 if ablation == 'no_stress' else 2.5,
                  w_sz=3.5, w_an=0.2)
    if ablation == 'init_only':
        P, s, hist = P0.copy(), s0.copy(), []
    else:
        P, s, hist = ref.run(P0, s0)
    if ablation not in ('init_only', 'no_micro'):
        P, s = ref.micro_tune(P, s, tau=0.12)
    dt = time.time() - t0
    if return_extra:
        return P, s, dt, dict(hist=hist, emb_hist=emb_hist, P0=P0, s0=s0)
    return P, s, dt


# ---------------------------------------------------------------- baselines
def run_random(data, shape, seed=0):
    t0 = time.time()
    n = len(data['X'])
    rng = np.random.default_rng(seed)
    P = shape.sample_inside(n, rng)
    s = init_scales(n, shape.area, data['aspects'])
    return P, s, time.time() - t0


def _pca_disk(X):
    Z = PCA(2).fit_transform(X)
    Z = (Z - Z.mean(0)) / (np.abs(Z).max() * 1.05)
    return Z


def run_pca(data, shape, seed=0):
    t0 = time.time()
    Z = _pca_disk(data['X'])
    P = shape.map_from_disk(Z, gamma=1.0)
    s = init_scales(len(Z), shape.area, data['aspects'])
    return P, s, time.time() - t0


def run_grid_las(data, shape, seed=0, fill=0.94):
    t0 = time.time()
    n = len(data['X'])
    Z = shape.map_from_disk(_pca_disk(data['X']), gamma=1.0)
    # grid cells inside the domain, sized so that #cells >= n
    cell = np.sqrt(shape.area / n) * 0.98
    lim = shape.R * 1.2
    g = np.arange(-lim, lim, cell)
    cx, cy = np.meshgrid(g + shape.c[0], g + shape.c[1])
    C = np.stack([cx.ravel(), cy.ravel()], 1)
    C = C[shape.sdf(C) < -cell * 0.7]
    while len(C) < n:
        cell *= 0.96
        g = np.arange(-lim, lim, cell)
        cx, cy = np.meshgrid(g + shape.c[0], g + shape.c[1])
        C = np.stack([cx.ravel(), cy.ravel()], 1)
        C = C[shape.sdf(C) < -cell * 0.7]
    cost = ((Z[:, None, :] - C[None, :, :]) ** 2).sum(-1)
    ri, ci = linear_sum_assignment(cost)
    P = C[ci]
    s = np.full(n, cell * fill)   # square cells; aspect handled at render
    return P, s, time.time() - t0


def run_han2016(data, shape, iters=500, seed=0):
    """Two-step scheme in the spirit of Han et al. (TCYB 2016).

    (i)  correlation-threshold grouping into tree levels; parent = most
         similar image in the previous level;
    (ii) recursive hyperbolic wedge placement (Lamping-Rao style);
    (iii) penalty-based continuous optimisation (no neighbourhood-stress
          term, anchor + overlap + shape + size only) and micro-tuning.
    """
    t0 = time.time()
    X, aspects = data['X'], data['aspects']
    n = len(X)
    ranks = np.arange(n)
    # cumulative-correlation grouping (their Eq. (1)-(2), normalised)
    D = np.linalg.norm(X[:, None] - X[None, :], axis=-1)
    sim = 1.0 / (1.0 + D)
    s_i = sim.mean(1)
    r = np.cumsum(s_i); r = (r - r[0]) / (r[-1] - r[0] + 1e-12)
    levels = np.minimum((r * 4).astype(int) + 1, 4); levels[0] = 0
    parent = np.zeros(n, int)
    for i in range(1, n):
        prev = np.where(levels == levels[i] - 1)[0]
        if len(prev) == 0:
            prev = np.where(levels < levels[i])[0]
        parent[i] = prev[np.argmax(sim[i, prev])] if len(prev) else 0
    # recursive wedge placement in the Poincare disk
    U = np.zeros((n, 2))
    children = [[] for _ in range(n)]
    for i in range(1, n):
        children[parent[i]].append(i)

    def place(i, th0, th1, rho):
        kids = children[i]
        if not kids:
            return
        m = len(kids)
        for t, j in enumerate(kids):
            th = th0 + (th1 - th0) * (t + 0.5) / m
            rr = np.tanh((rho + 0.9) / 2)
            U[j] = [rr * np.cos(th), rr * np.sin(th)]
            w = (th1 - th0) / m
            place(j, th - 0.45 * w, th + 0.45 * w, rho + 0.9)

    import sys
    sys.setrecursionlimit(10000)
    place(0, -np.pi, np.pi, 0.0)
    P0 = shape.map_from_disk(U)
    s0 = init_scales(n, shape.area, aspects)
    pairs = np.stack([np.arange(1, n), parent[1:]], 1)
    pairs = np.sort(pairs, 1)
    ref = Refiner(shape, aspects, ranks, pairs,
                  np.full(len(pairs), np.sqrt(shape.area / n)),
                  w_st=0.0, iters=iters, seed=seed)
    P, s, _ = ref.run(P0, s0)
    P, s = ref.micro_tune(P, s)
    return P, s, time.time() - t0


METHODS = dict(random=run_random, pca=run_pca, grid_las=run_grid_las,
               han2016=run_han2016, halo=run_halo)
