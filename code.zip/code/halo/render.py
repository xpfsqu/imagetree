"""Render layouts with the actual thumbnails (for the qualitative figures)."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .layout import base_halves


def render(ax, shape, P, s, aspects, thumbs, ranks=None, title=None,
           square=False):
    Wh, Hh = base_halves(np.ones_like(s) if square else aspects)
    a, b = s * Wh, s * Hh
    order = np.argsort(-np.asarray(ranks if ranks is not None
                                   else np.arange(len(s))))
    bd = shape.boundary()
    ax.fill(bd[:, 0], bd[:, 1], color="#f2f2f2", zorder=0)
    ax.plot(bd[:, 0], bd[:, 1], color="#999999", lw=1.0, zorder=1)
    for i in order:                       # draw low-rank first, top-rank last
        ax.imshow(thumbs[i], extent=(P[i, 0] - a[i], P[i, 0] + a[i],
                                     P[i, 1] - b[i], P[i, 1] + b[i]),
                  zorder=2, interpolation="bilinear", origin="lower")
    lim = shape.R * 1.25
    ax.set_xlim(shape.c[0] - lim, shape.c[0] + lim)
    ax.set_ylim(shape.c[1] - lim, shape.c[1] + lim)
    ax.set_aspect("equal")
    ax.axis("off")
    if title:
        ax.set_title(title, fontsize=9)
